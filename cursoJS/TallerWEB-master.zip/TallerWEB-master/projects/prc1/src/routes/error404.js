'use strict'

module.exports = function( req, res ){
	res.sendStatus(404)
}