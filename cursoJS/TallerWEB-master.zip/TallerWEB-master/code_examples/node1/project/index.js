'use strict'

var Controller = require('./lib/controller')
var Model = require('./lib/model')

var Renderer = require('Game-Renderer')

// ...